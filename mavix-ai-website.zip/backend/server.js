const express = require('express');
const app = express();
app.get('/', (req, res) => res.send('Mavix AI API'));
app.listen(3001, () => console.log('Server running'));