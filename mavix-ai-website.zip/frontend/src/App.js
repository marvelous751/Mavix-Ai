import React from 'react';
function App() {
  return <h1>Welcome to Mavix AI</h1>;
}
export default App;